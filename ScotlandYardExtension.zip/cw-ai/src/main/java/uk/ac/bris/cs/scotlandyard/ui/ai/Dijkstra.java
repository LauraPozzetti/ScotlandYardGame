package uk.ac.bris.cs.scotlandyard.ui.ai;
import uk.ac.bris.cs.scotlandyard.model.*;
import uk.ac.bris.cs.scotlandyard.model.Ticket;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.*;
import java.lang.Thread.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.function.Consumer;

import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;
import static uk.ac.bris.cs.scotlandyard.model.Colour.Black;
import static uk.ac.bris.cs.scotlandyard.model.Ticket.Taxi;

import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Graph;

public class Dijkstra {
      List<DijkstraNode> nodeList;

    /*public Dijkstra(ScotlandYardView view, Colour colour, int source) {
        Graph<Integer, Transport> graph = view.getGraph();

        nodeList = new ArrayList<>();
        //System.out.println("Giocatore " + colour + " posizione " + view.getPlayerLocation(colour) + source);
        if(view.getPlayerLocation(colour) > 0 && view.getPlayerLocation(colour) < (graph.getNodes().size() + 1)){
            //initialization
            for (int i = 0; i < graph.getNodes().size()+1; i++) {
                nodeList.add(new DijkstraNode(i));
              }
            nodeList.get(view.getPlayerLocation(colour)).setDistance(0);
        //    System.out.println(nodeList.get(source).getDistance());

             int current = minDistance();
             while(current != -1){
                nodeList.get(current).setVisited(true);
                Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(current));
                for (Edge<Integer, Transport> e : edges) {
                    if (nodeList.get(e.destination().value()).getDistance() > nodeList.get(current).getDistance() + 1) {
                        if (checkTicket(view, current, colour, Ticket.fromTransport(e.data()) )) {
                            nodeList.get(e.destination().value()).setDistance(nodeList.get(current).getDistance() + 1);
                            nodeList.get(e.destination().value()).setPrevious(nodeList.get(current));
                            refreshTicket(view, current, Ticket.fromTransport(e.data()), e.destination().value());
                        }
                    }
                }
                current = minDistance();
            }
        }

    }*/

    // distanze di un giocatore in base ai suoi biglietti
    public Dijkstra(ScotlandYardView view, Colour colour) {
        Graph<Integer, Transport> graph = view.getGraph();

        nodeList = new ArrayList<>();
        System.out.println("Giocatore " + colour + " posizione " + view.getPlayerLocation(colour));
        System.out.println("location " + (view.getPlayerLocation(colour) > 0) );
        System.out.println(" < 200 " +  (view.getPlayerLocation(colour) < (graph.getNodes().size() + 1)));
        System.out.println(view.getPlayerLocation(colour) > 0 && view.getPlayerLocation(colour) < (graph.getNodes().size() + 1));
        if(view.getPlayerLocation(colour) > 0 && view.getPlayerLocation(colour) < (graph.getNodes().size() + 1)){
            //initialization
            for (int i = 0; i < graph.getNodes().size()+1; i++) {
                nodeList.add(new DijkstraNode(i));
            }
            nodeList.get(view.getPlayerLocation(colour)).setDistance(0);
            //    System.out.println(nodeList.get(source).getDistance());

            int current = minDistance();
            while(current != -1){
                nodeList.get(current).setVisited(true);
                Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(current));
                for (Edge<Integer, Transport> e : edges) {
                    if (nodeList.get(e.destination().value()).getDistance() > nodeList.get(current).getDistance() + 1) {
                        if (checkTicket(view, current, colour, Ticket.fromTransport(e.data()) )) {
                            nodeList.get(e.destination().value()).setDistance(nodeList.get(current).getDistance() + 1);
                            nodeList.get(e.destination().value()).setPrevious(nodeList.get(current));
                            refreshTicket(view, current, Ticket.fromTransport(e.data()), e.destination().value());
                        }
                    }
                }
                current = minDistance();
            }
        }
        System.out.println("Arrivata qui");
    }

    public Dijkstra(ScotlandYardView view, MiniMaxPlayer player, int position) {
        Graph<Integer, Transport> graph = view.getGraph();

        nodeList = new ArrayList<>();

        if(position< (graph.getNodes().size() + 1)){
            //initialization
            for (int i = 0; i < graph.getNodes().size()+1; i++) {
                nodeList.add(new DijkstraNode(i));
            }
            nodeList.get(position).setDistance(0);
            //    System.out.println(nodeList.get(source).getDistance());

            int current = minDistance();
            while(current != -1){
                nodeList.get(current).setVisited(true);
                Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(current));
                for (Edge<Integer, Transport> e : edges) {
                    if (nodeList.get(e.destination().value()).getDistance() > nodeList.get(current).getDistance() + 1) {
                        if (checkTicket(view, current, player, Ticket.fromTransport(e.data()) )) {
                            nodeList.get(e.destination().value()).setDistance(nodeList.get(current).getDistance() + 1);
                            nodeList.get(e.destination().value()).setPrevious(nodeList.get(current));
                            refreshTicket(view, current, Ticket.fromTransport(e.data()), e.destination().value());
                        }
                    }
                }
                current = minDistance();
            }
        }
    }


    private boolean checkTicket(ScotlandYardView view, int current, Colour colour, Ticket ticket){
        boolean check = true;
        //if (colour == Colour.Black) return check;
        if (ticket == Ticket.Taxi) {
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi() + 1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Bus){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()+1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Underground){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()+1) check = false;
        }
        return check;
    }

    private boolean checkTicket(ScotlandYardView view, int current, MiniMaxPlayer player, Ticket ticket){
        boolean check = true;
        //if (colour == Colour.Black) return check;
        if (ticket == Ticket.Taxi) {
            if (player.getTaxi() < nodeList.get(current).getTaxi() + 1) check = false;
            if (player.getBus() < nodeList.get(current).getBus()) check = false;
            if (player.getUnderground() < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Bus){
            if (player.getTaxi() < nodeList.get(current).getTaxi()) check = false;
            if (player.getBus() < nodeList.get(current).getBus()+1) check = false;
            if (player.getUnderground() < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Underground){
            if (player.getTaxi() < nodeList.get(current).getTaxi()) check = false;
            if (player.getBus() < nodeList.get(current).getBus()) check = false;
            if (player.getUnderground() < nodeList.get(current).getUnderground()+1) check = false;
        }
        return check;
    }


    private void refreshTicket(ScotlandYardView view, int current, Ticket ticket, int destination){
        if (ticket == Ticket.Taxi) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi() + 1);
            nodeList.get(destination).setBus( nodeList.get(current).getBus());
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground());
         }
        if (ticket == Ticket.Bus) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi());
            nodeList.get(destination).setBus( nodeList.get(current).getBus()+1);
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground());
        }
        if (ticket == Ticket.Underground) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi());
            nodeList.get(destination).setBus( nodeList.get(current).getBus());
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground()+1);
        }
    }

    private int minDistance () {
        int x = Integer.MAX_VALUE;
        int y = -1;   // graph not connected, or no unvisited vertices
        for (int i=0; i<nodeList.size(); i++) {
            if (!nodeList.get(i).getVisited() && nodeList.get(i).getDistance()<x) {
                y=i;
                x=nodeList.get(i).getDistance();}
        }
        return y;
    }

    public int getDistance(int destination){  return nodeList.get(destination).getDistance();    }

    public int getNumberTaxi(int destination){
        return nodeList.get(destination).getTaxi();
    }

    public int getNumberBus(int destination){
        return nodeList.get(destination).getBus();
    }

    public int getNumberUnderground(int destination){
        return nodeList.get(destination).getUnderground();
    }
 }


