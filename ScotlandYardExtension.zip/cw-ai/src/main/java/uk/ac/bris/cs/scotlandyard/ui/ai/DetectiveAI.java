package uk.ac.bris.cs.scotlandyard.ui.ai;

import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Graph;
import uk.ac.bris.cs.scotlandyard.ai.ManagedAI;
import uk.ac.bris.cs.scotlandyard.ai.PlayerFactory;
import uk.ac.bris.cs.scotlandyard.ai.ResourceProvider;
import uk.ac.bris.cs.scotlandyard.ai.Visualiser;
import uk.ac.bris.cs.scotlandyard.model.*;

import java.util.*;
import java.util.function.Consumer;

// TODO name the AI
@ManagedAI("DetectiveAI")
public class DetectiveAI implements PlayerFactory, MoveVisitor, Spectator {

    @Override
    public List<Spectator> createSpectators(ScotlandYardView view){
        System.out.println("creo spectator");
        List<Spectator> spectators = new ArrayList<>();

        spectators.add(new Spectator(){});
        return spectators;
    }

    @Override
    public void ready(Visualiser visualiser,
               ResourceProvider provider){System.out.println("Il gioco inizia");}

    @Override
    public void finish() {System.out.println("Il gioco finisce");}

    @Override
    public void onMoveMade(ScotlandYardView view,
                           Move move){System.out.println("Mossa comunicata " + move);}

    Graph<Integer, Transport> graph;


    // TODO create a new player here
    @Override
    public Player createPlayer(Colour colour) {
        return new MyPlayer();
    }

    // TODO A sample player that selects a random move
    private static class MyPlayer implements Player {
        int minDistance;
        int distance;
        boolean nextTicket;
        boolean nextUnderground;
        int nOfTransport;

        private final Random random = new Random();

        @Override
        public void makeMove(ScotlandYardView view, int location, Set<Move> moves,
                             Consumer<Move> callback) {
            System.out.println("Detective posizione " + location);
            Move m = bestMove(view,moves,location);
            System.out.println ("Round " + view.getCurrentRound()+1 + " mossa scelta " + m);
            //callback.accept(m);
            //callback.accept(bestMove(view,moves,location));
            callback.accept(new ArrayList<>(moves).get(random.nextInt(moves.size())));
        }


        private Move bestMove(ScotlandYardView view, Set<Move> moves, int location) {
            int bestScore = - Integer.MAX_VALUE;
            int mScore;
            Move bestM = new ArrayList<>(moves).get(0);
            System.out.println("mrx position" + view.getPlayerLocation(view.getPlayers().get(0)));
            Dijkstra alg = new Dijkstra(view, view.getPlayers().get(0));

            System.out.println("Black is " + view.getPlayerLocation(view.getPlayers().get(0)));
            //if (view.getCurrentRound() == 3 || view.getCurrentRound() == 8 || view.getCurrentRound() == 13
              //      || view.getCurrentRound() == 18 || view.getCurrentRound() == 24) minDistance(alg,moves);
            if (view.getCurrentRound()>= 3) minDistance(alg,moves);

                for (Move m: moves){
                mScore = score(view,m, alg,location);
                if (mScore > bestScore){
                    bestScore = mScore;
                    bestM = m;
                }

            }

            return bestM;
        }

        private int score(ScotlandYardView view, Move move, Dijkstra alg, int location){
                int score=0;

            // vedere se il detective ha un biglietto di quella fermata per la prossima mossa
            if (nextTicket(view,move))
               score = score + 1;
            else score = -1000;

            //vedere se la fermata ha più scambi
            nOfTransport(view,move);
            switch(nOfTransport){
                case 1:
                    score = score + 1;
                    break;
                case 11:
                    score = score + 2;
                    break;
                case 111:
                    score = score + 3;
                    break;
            }

            //vedere se una fermata successiva è underground
            //if (nextUnderground (view,move)) score = score + 1;

            // vedere se la prossima è reveal: preferire in questo caso una fermata con tutti i mezzi (compresa metro)
            if (view.getCurrentRound() == 2 || view.getCurrentRound() == 7 || view.getCurrentRound() == 12
                    || view.getCurrentRound() == 17 || view.getCurrentRound() == 23) {
                if (nextUnderground (view,move)) score = score + 3;
            }
            // vedere se è reveal: calcolare distanza da mrX
           // if (view.getCurrentRound() == 3 || view.getCurrentRound() == 8 || view.getCurrentRound() == 13
             //       || view.getCurrentRound() == 18 || view.getCurrentRound() == 24) {
            if (view.getCurrentRound()>= 3) {
                    System.out.println(" " + view.getPlayerLocation(Colour.Black));
                if (getDistance(alg,move) == minDistance)  score = score + 10;
            }

            System.out.println("Score " + score + " " + move);
            return score;
        }


        private void setNextTicket(boolean nextT){
            nextTicket = nextT;
        }

        private void setNOfTransport(int n){
            nOfTransport = n;
        }

        private void setNextUnderground(boolean nU){
            nextUnderground = nU;
        }

        private void setMinDistance(int v){ minDistance = v; }

        private void setDistance(int v){ distance = v; }

        private int getMinDistance(){
            return minDistance;
        }

        private int minDistance(Dijkstra dijkstra, Set<Move> moves){
            for (Move m: moves) {
                m.visit(new MoveVisitor() {

                    public void visit(PassMove move) {
                    }

                    public void visit(TicketMove move) {
                        int distance = dijkstra.getDistance(move.destination());
                        if (distance < getMinDistance()) setMinDistance(distance);
                    }

                    public void visit(DoubleMove move) {
                        int distance = dijkstra.getDistance(move.secondMove().destination());
                        if (distance < getMinDistance()) setMinDistance(distance);
                    }
                });
            }

            return minDistance;
        }

        private int getDistance(Dijkstra alg, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    setDistance(alg.getDistance(move.destination()));
                }

                public void visit(DoubleMove move) {
                    setDistance(alg.getDistance(move.secondMove().destination()));
                }
            });
            return distance;
        }


        private boolean nextTicket(ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean nextT = false;
                    for (Edge<Integer, Transport> e : edges)
                        if (view.getPlayerTickets(view.getCurrentPlayer(), Ticket.fromTransport(e.data())) != 0) nextT = true;
                    setNextTicket(nextT);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean nextT = false;
                    for (Edge<Integer, Transport> e : edges)
                        if (view.getPlayerTickets(view.getCurrentPlayer(), Ticket.fromTransport(e.data())) != 0) nextT = true;
                    setNextTicket(nextT);
                }
            });

            return nextTicket;
        }

        private int nOfTransport(ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean bus = false;
                    boolean taxi = false;
                    boolean underground = false;

                    for (Edge<Integer, Transport> e : edges) {
                        if (Ticket.fromTransport(e.data()) == Ticket.Taxi) taxi = true;
                        else {
                            if (Ticket.fromTransport(e.data()) == Ticket.Bus) bus = true;
                            else underground = true;
                        }
                    }
                    int n = 0;
                    if (taxi) n = n + 1;
                    if (bus) n = n + 10;
                    if (underground) n = n+ 100;

                    setNOfTransport(n);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean bus = false;
                    boolean taxi = false;
                    boolean underground = false;

                    for (Edge<Integer, Transport> e : edges) {
                        if (Ticket.fromTransport(e.data()) == Ticket.Taxi) taxi = true;
                        else {
                            if (Ticket.fromTransport(e.data()) == Ticket.Bus) bus = true;
                            else underground = true;
                        }
                    }
                    int n = 0;
                    if (taxi) n = n + 1;
                    if (bus) n = n + 10;
                    if (underground) n = n+ 100;
                    setNOfTransport(n);
                }
            });

            return nOfTransport;
        }

        private boolean nextUnderground (ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean nextU = false;

                    for (Edge<Integer, Transport> e : edges) {
                        Collection<Edge<Integer, Transport>> edges2 = graph.getEdgesFrom(graph.getNode(e.destination().value()));
                        for (Edge<Integer, Transport> e2 : edges2) {
                            if (Ticket.fromTransport(e2.data()) == Ticket.Underground) nextU = true;
                        }
                    }
                   setNextUnderground(nextU);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean nextU = false;

                    for (Edge<Integer, Transport> e : edges) {
                        Collection<Edge<Integer, Transport>> edges2 = graph.getEdgesFrom(graph.getNode(e.destination().value()));
                        for (Edge<Integer, Transport> e2 : edges2) {
                            if (Ticket.fromTransport(e2.data()) == Ticket.Underground) nextU = true;
                        }
                    }
                    setNextUnderground(nextU);
                }
            });

            return nextUnderground;
        }


    }
}
