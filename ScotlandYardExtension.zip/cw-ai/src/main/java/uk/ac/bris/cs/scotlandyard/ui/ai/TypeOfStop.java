package uk.ac.bris.cs.scotlandyard.ui.ai;


public enum TypeOfStop {
    OnlyTaxi, TaxiAndBus, AllStops;

     public boolean isOnlyTaxi() {
        return this == OnlyTaxi;
    }

     public boolean isTaxiAndBus() {
        return this == TaxiAndBus;
    }

     public boolean isAllStops() {
        return this == AllStops;
    }
}