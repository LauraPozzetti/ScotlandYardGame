package uk.ac.bris.cs.scotlandyard.ui.ai;

import java.util.ArrayList;
import java.util.Set;
import java.util.function.Consumer;

import uk.ac.bris.cs.scotlandyard.ai.ManagedAI;
import uk.ac.bris.cs.scotlandyard.ai.PlayerFactory;
import uk.ac.bris.cs.scotlandyard.model.Colour;
import uk.ac.bris.cs.scotlandyard.model.Move;
import uk.ac.bris.cs.scotlandyard.model.Player;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardView;
import uk.ac.bris.cs.scotlandyard.model.Transport;
import uk.ac.bris.cs.scotlandyard.model.*;

import java.util.Collection;
import java.util.*;
import uk.ac.bris.cs.scotlandyard.model.MoveVisitor;

import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Graph;

// TODO name the AI
@ManagedAI("MrXAIminimax")
public class MrXAIminimax implements PlayerFactory, MoveVisitor {

    Graph<Integer, Transport> graph;

    // TODO create a new player here
    @Override
    public Player createPlayer(Colour colour) {
        return new MyPlayer();
    }

    private static class MyPlayer implements Player {
        MiniMaxPlayer maxPlayer;
        MiniMaxPlayer minPlayer;
        Ticket moveTicket;
        TypeOfStop typeOfStop;
        boolean safeDistance;
        boolean nextTicket;
        boolean doubleMove;
        boolean detectivesHaveTickets;
        boolean nextUnderground;
        int distance;
        int level;

        @Override
        public void makeMove(ScotlandYardView view, int location, Set<Move> moves,
                             Consumer<Move> callback) {
           if (view.getPlayers().size() == 2) callback.accept(MiniMax(view, moves, location));
            else callback.accept(scoreMove(view,moves,location));
        }

        /*************************************************************************************************************************************
                                                            ScoreMove if at least two detectives
         **************************************************************************************************************************************/

        private Move scoreMove(ScotlandYardView view, Set<Move> moves, int location) {
            int bestScore = - Integer.MAX_VALUE;
            int mScore;
            Move bestMove = new ArrayList<>(moves).get(0);

            // calculate number of moves for detective to reach each location
            Set<Dijkstra> alg = new HashSet<>();
            for(int i=1; i < view.getPlayers().size(); i++) alg.add(new Dijkstra(view, view.getPlayers().get(i)));

            for (Move m: moves){
                mScore = score(view,m,alg);
                if (mScore > bestScore){
                    bestScore = mScore;
                    bestMove = m;
                }
            }
            return bestMove;
        }

        private int score(ScotlandYardView view, Move move, Set<Dijkstra> alg){
            int score;

            // check if distance safe (at least two moves away from each detective)
            if (safeDistance(alg, move))
                score = distance;
            else score = -100;

            // check if mrX already has suitable ticket for next move
            if (playerHasNextTicket(view,move,Colour.Black))
                score = score + 1;
            else score = -100;

            //check how many connections the next stop has and check abundance of types of ticket
            nTypeOfStop(view,move);
            if (typeOfStop.isOnlyTaxi()) score = score + 1;
               if (typeOfStop.isTaxiAndBus()){
                score = score + 5;
                if (max(view.getPlayerTickets(Colour.Black, Ticket.Taxi), view.getPlayerTickets(Colour.Black, Ticket.Bus)) == view.getPlayerTickets(Colour.Black, Ticket.Bus)){
                    if (getMoveTicket(move) == Ticket.Bus) score = score + 5;
                }
                else{
                     if (getMoveTicket(move) == Ticket.Taxi) score = score + 5;
                }
            }
            if (typeOfStop.isAllStops()){
                 score = score + 10;
                if (max(view.getPlayerTickets(Colour.Black, Ticket.Taxi), view.getPlayerTickets(Colour.Black, Ticket.Bus), view.getPlayerTickets(Colour.Black, Ticket.Underground)) == view.getPlayerTickets(Colour.Black, Ticket.Underground)) {
                    if (getMoveTicket(move) == Ticket.Underground) score = score + 5;
                    else if (max(view.getPlayerTickets(Colour.Black, Ticket.Taxi), view.getPlayerTickets(Colour.Black, Ticket.Bus)) == view.getPlayerTickets(Colour.Black, Ticket.Bus)) {
                        if (getMoveTicket(move) == Ticket.Bus) score = score + 5;
                    } else if (getMoveTicket(move) == Ticket.Taxi) score = score + 5;
                }
            }

            //check if detectives have suitable ticket to reach destination (in case not safe)
            if (!detectivesHaveTickets(view)) score = score + 3;

            // check if reveal round: prefer a destination with all transportation followed by secret move
            if (view.getCurrentRound() == 2 || view.getCurrentRound() == 7 || view.getCurrentRound() == 12
                    || view.getCurrentRound() == 17 || view.getCurrentRound() == 23) {
                if (isDoubleMove(view, move)) {
                    if (((DoubleMove) move).firstMove().ticket() != Ticket.Secret && ((DoubleMove) move).firstMove().ticket() == Ticket.Secret) {
                        if (typeOfStop.isAllStops()) score = score + 40;
                        else score = score + 30;
                    }
                    else {
                        if (((DoubleMove) move).firstMove().ticket() == Ticket.Secret && ((DoubleMove) move).firstMove().ticket() != Ticket.Secret) {
                            if (typeOfStop.isAllStops()) score = score + 30;
                            else score = score + 5;
                        }
                        else if (((DoubleMove) move).firstMove().ticket() == Ticket.Secret && ((DoubleMove) move).firstMove().ticket() == Ticket.Secret) {
                            score = score - 10;
                        }
                    }
                }
                else{
                    if (((TicketMove) move).ticket() == Ticket.Secret) score = score + 5;
                    if (typeOfStop.isAllStops()) score = score + 20;
                }
            }
            else{
                if (isDoubleMove(view,move)) score = score - 10;
                else{
                    if (((TicketMove) move).ticket() == Ticket.Secret) score = score - 20;
                }
            }

            return score;
        }

        private boolean safeDistance(Set<Dijkstra> alg, Move m){
            m.visit(new MoveVisitor() {
                int meanDistance;

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    boolean safe = true;
                    for (Dijkstra dijkstra: alg){
                        if (dijkstra.getDistance(move.destination()) < 2) safe = false;
                         else meanDistance = meanDistance + move.destination();
                    }
                    setSafeDistance(safe);
                    setDistance(meanDistance);
                }

                public void visit(DoubleMove move) {
                    boolean safe = true;
                    for (Dijkstra dijkstra: alg){
                        if (dijkstra.getDistance(move.secondMove().destination()) < 2) safe = false;
                        else meanDistance = meanDistance + move.secondMove().destination();
                    }
                    setSafeDistance(safe);
                    setDistance(meanDistance);
                }
            });
            return safeDistance;
        }

        private boolean playerHasNextTicket(ScotlandYardView view, Move m, Colour colour){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean nextT = false;
                    for (Edge<Integer, Transport> e : edges)
                        if (view.getPlayerTickets(colour, Ticket.fromTransport(e.data())) != 0) nextT = true;
                    setNextTicket(nextT);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean nextT = false;
                    for (Edge<Integer, Transport> e : edges)
                        if (view.getPlayerTickets(colour, Ticket.fromTransport(e.data())) != 0) nextT = true;
                    setNextTicket(nextT);
                }
            });

            return nextTicket;
        }

        private TypeOfStop nTypeOfStop(ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean bus = false;
                    boolean taxi = false;
                    boolean underground = false;

                    for (Edge<Integer, Transport> e : edges) {
                        if (Ticket.fromTransport(e.data()) == Ticket.Taxi) taxi = true;
                        else {
                            if (Ticket.fromTransport(e.data()) == Ticket.Bus) bus = true;
                            else underground = true;
                        }
                    }

                    if (taxi && !bus && !underground) typeOfStop = TypeOfStop.OnlyTaxi;
                    if (taxi && bus && !underground) typeOfStop = TypeOfStop.TaxiAndBus;
                    if (taxi && bus && underground) typeOfStop = TypeOfStop.AllStops;

                    setTypeOfStop(typeOfStop);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean bus = false;
                    boolean taxi = false;
                    boolean underground = false;

                    for (Edge<Integer, Transport> e : edges) {
                        if (Ticket.fromTransport(e.data()) == Ticket.Taxi) taxi = true;
                        else {
                            if (Ticket.fromTransport(e.data()) == Ticket.Bus) bus = true;
                            else underground = true;
                        }
                    }
                    if (taxi && !bus && !underground) typeOfStop = TypeOfStop.OnlyTaxi;
                    if (taxi && bus && !underground) typeOfStop = TypeOfStop.TaxiAndBus;
                    if (taxi && bus && underground) typeOfStop = TypeOfStop.AllStops;

                    setTypeOfStop(typeOfStop);             }
            });

            return typeOfStop;
        }

        private boolean isDoubleMove(ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                    setDoubleMove(false);
                }

                public void visit(TicketMove move) {
                   setDoubleMove(false);
                }

                public void visit(DoubleMove move) {
                    setDoubleMove(true);
                }
            });

            return doubleMove;
        }

        private Ticket getMoveTicket(Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {setMoveTicket(move.ticket());}

                public void visit(DoubleMove move) {
                    setMoveTicket(move.secondMove().ticket());
                }
            });

            return moveTicket;
        }

        private boolean detectivesHaveTickets(ScotlandYardView view){
            detectivesHaveTickets = true;
            for(int i=1; i < view.getPlayers().size(); i++) {
                if (typeOfStop.isOnlyTaxi())
                     if (view.getPlayerTickets(view.getPlayers().get(i), Ticket.Taxi) == 0) detectivesHaveTickets= false;
                else{
                    if (typeOfStop.isTaxiAndBus())
                        if (view.getPlayerTickets(view.getPlayers().get(i), Ticket.Taxi) == 0 && view.getPlayerTickets(view.getPlayers().get(i), Ticket.Bus) == 0) detectivesHaveTickets= false;
                        else if (view.getPlayerTickets(view.getPlayers().get(i), Ticket.Taxi) == 0 && view.getPlayerTickets(view.getPlayers().get(i), Ticket.Bus) == 0 &&
                                view.getPlayerTickets(view.getPlayers().get(i), Ticket.Underground) == 0) detectivesHaveTickets= false;
                }
            }
            return detectivesHaveTickets;
        }

        private void setSafeDistance(boolean safeValue){
            safeDistance = safeValue;
        }

        private void setDistance(int value){
            distance = value;
        }

        private void setNextTicket(boolean nextT){
            nextTicket = nextT;
        }

        private void setMoveTicket(Ticket t){
            moveTicket = t;
        }

        private void setTypeOfStop(TypeOfStop type){
            typeOfStop = type;
        }

        private void setDoubleMove(boolean dM){
            doubleMove = dM;
        }

        /*************************************************************************************************************************************
                                        MiniMax if game has two players
         **************************************************************************************************************************************/

        private Move MiniMax(ScotlandYardView view, Set<Move> moves, int location){
            int bestValue = -Integer.MAX_VALUE;
            Move bestMove = new ArrayList<>(moves).get(0);
            level = 0;
            maxPlayer = new MiniMaxPlayer(view, view.getPlayers().get(0), location, true);
            minPlayer = new MiniMaxPlayer(view, view.getPlayers().get(1), view.getPlayerLocation(view.getPlayers().get(1)),false);
            int depth = 4;

            //Dijkstra alg = new Dijkstra(view, minPlayer, minPlayer.getPosition(0));
            for (Move m: moves){
                level++;
                maxPlayer.removeTicket(m);
                maxPlayer.setPosition(m, level);
                int max = maximize(view, m, depth);
                level--;
                maxPlayer.addTicket(m);
                if (max > bestValue) {
                    bestValue = max;
                    bestMove = m;
                }
            }
            System.out.println("Move chosen by score " + bestValue + " " + bestMove + " round " + maxPlayer.getRound());
            return bestMove;
        }

        private int maximize(ScotlandYardView view, Move move, int depth) {
            int score;

            if (level!= 0) {
                nTypeOfStop(view,move);
                int test = maxCheckEndGame(view, level, depth);
                if (test != Integer.MAX_VALUE) {
                    if (test == 0)
                        return score(view, move, new Dijkstra(view, minPlayer, minPlayer.getPosition(level - 1)));
                    else return test;
                }
            }

            int alfa = -Integer.MAX_VALUE;
            int maxValue = -Integer.MAX_VALUE;
            for (Move m: validMoves(view, minPlayer, minPlayer.getPosition((level-1)))) {
                level++;
                minPlayer.removeTicket(m);
                maxPlayer.addDetectiveTicketToMrX(m);
                minPlayer.setPosition(m,level);
                score = minimize(view, m, depth);
                level--;
                maxPlayer.removeDetectiveTicketFromMrX(m);
                minPlayer.addTicket(m);
                if (score < alfa) break;
                else alfa = score;
                maxValue = max(maxValue,score);
            }
            if(alfa == -Integer.MAX_VALUE) return 200;

            return(maxValue);
        }

        private int minimize(ScotlandYardView view, Move move, int depth) {
            int score;

            int test = minCheckEndGame(view,level,depth);
            if (test != Integer.MAX_VALUE) {
                if (test == 0) return scoreDetective(view,move,minPlayer.colour());
                else return test;
            }

            int beta = +Integer.MAX_VALUE;
            int minValue = +Integer.MAX_VALUE;
            for (Move m: validMoves(view, maxPlayer, maxPlayer.getPosition((level-1)))) {
                level++;
                maxPlayer.removeTicket(m);
                maxPlayer.setPosition(m,level);
                score = maximize(view,m,depth);
                level--;
                maxPlayer.addTicket(m);
                if (score > beta) break;
                else beta = score;
                minValue = min(minValue, score);
            }
            if(beta == +Integer.MAX_VALUE) return -100;

            return(minValue);
        }

        private int min(int v1, int v2){
                if (v1 < v2) return v1;
                else return v2;
        }

        private int max(int v1, int v2){
            if (v1 > v2) return v1;
            else return v2;
        }

        private int max(int v1, int v2,int v3){
            if (v1 > v2)
                if (v1 > v3) return v1;
                else return v3;
            else
                if (v2 > v3) return v2;
                else return v3;
        }

        private int maxCheckEndGame(ScotlandYardView view, int level, int depth){
            //MiniMax
            if (level == depth) return 0;
            //mrX excaped
            if (maxPlayer.getRound() > 24) return 1000;
            //mrX captured
            if (maxPlayer.getPosition((level))== minPlayer.getPosition(level-1)) return -1000;
            //detective has no tickets
            if(!detectiveHasTickets()) return 1000;
            //detective stuck
            if (validMoves(view, minPlayer, minPlayer.getPosition((level-1))).contains(new PassMove(minPlayer.colour()))) return 1000;
            else return Integer.MAX_VALUE;
        }

        private int minCheckEndGame(ScotlandYardView view, int level, int depth){
            //Minimax
            if (level == depth) return 0;
            //mrX captured
             if (maxPlayer.getPosition((level-1))== minPlayer.getPosition(level)) return -1000;
             //mrX stuck
             if (validMoves(view, maxPlayer, maxPlayer.getPosition((level-1))).size() == 0) return -1000;
            else return Integer.MAX_VALUE;
        }

         private boolean safeDistance(Dijkstra alg, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    boolean safe = true;
                    if (alg.getDistance(move.destination()) < 2) safe = false;
                    else setDistance(alg.getDistance(move.destination()));
                    setSafeDistance(safe);
                }

                public void visit(DoubleMove move) {
                    boolean safe = true;
                    if (alg.getDistance(move.secondMove().destination()) < 2) safe = false;
                    else setDistance(alg.getDistance(move.secondMove().destination()));
                    setSafeDistance(safe);
                }
            });
            return safeDistance;
        }

        private Set<Move> validMoves(ScotlandYardView view, MiniMaxPlayer player, int location) {
            Collection<Edge<Integer, Transport>> edges = view.getGraph().getEdgesFrom(view.getGraph().getNode(location));
            Set<Move> tM = new HashSet<>();
            for (Edge<Integer, Transport> e : edges) {
                if (player.getPlayerTickets(Ticket.fromTransport(e.data())) > 0) {
                    tM.add(new TicketMove(player.colour(), Ticket.fromTransport(e.data()), e.destination().value()));
                }
            }
            if (!player.isMrX() && tM.size() == 0) tM.add(new PassMove(player.colour()));

            return tM;
        }

        private boolean detectiveHasTickets(){
            detectivesHaveTickets = true;
            if (typeOfStop.isOnlyTaxi())
                if (minPlayer.getTaxi() == 0) detectivesHaveTickets= false;
                else{
                    if (typeOfStop.isTaxiAndBus())
                        if (minPlayer.getTaxi() == 0 && minPlayer.getBus() == 0) detectivesHaveTickets= false;
                        else if (minPlayer.getTaxi() == 0 && minPlayer.getBus() == 0 &&
                                minPlayer.getUnderground() == 0) detectivesHaveTickets= false;
                }

            return detectivesHaveTickets;
        }

        private void setNextUnderground(boolean nU){
            nextUnderground = nU;
        }

        private boolean nextUnderground (ScotlandYardView view, Move m){
            m.visit(new MoveVisitor() {

                public void visit(PassMove move) {
                }

                public void visit(TicketMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.destination()));
                    boolean nextU = false;

                    for (Edge<Integer, Transport> e : edges) {
                        Collection<Edge<Integer, Transport>> edges2 = graph.getEdgesFrom(graph.getNode(e.destination().value()));
                        for (Edge<Integer, Transport> e2 : edges2) {
                            if (Ticket.fromTransport(e2.data()) == Ticket.Underground) nextU = true;
                        }
                    }
                    setNextUnderground(nextU);
                }

                public void visit(DoubleMove move) {
                    Graph<Integer, Transport> graph = view.getGraph();
                    Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(move.secondMove().destination()));
                    boolean nextU = false;

                    for (Edge<Integer, Transport> e : edges) {
                        Collection<Edge<Integer, Transport>> edges2 = graph.getEdgesFrom(graph.getNode(e.destination().value()));
                        for (Edge<Integer, Transport> e2 : edges2) {
                            if (Ticket.fromTransport(e2.data()) == Ticket.Underground) nextU = true;
                        }
                    }
                    setNextUnderground(nextU);
                }
            });

            return nextUnderground;
        }

        private int score(ScotlandYardView view, Move move, Dijkstra alg){
            int score;
            // check if distance safe (at least two moves away from each detective)
            if (safeDistance(alg, move))
                score = distance;
            else score = -100;

            // check if mrX already has suitable ticket for next move
            if (playerHasNextTicket(view,move,Colour.Black))
                score = score + 1;
            else score = score -1000;

            //check how many connections the next stop has and check abundance of types of ticket
            nTypeOfStop(view,move);
            if (typeOfStop.isOnlyTaxi()) score = score + 1;
            if (typeOfStop.isTaxiAndBus()){
                score = score + 5;
                if (max(maxPlayer.getTaxi(), maxPlayer.getBus()) == maxPlayer.getBus()){
                    if (getMoveTicket(move) == Ticket.Bus) score = score + 5;
                }
                else{
                   if (getMoveTicket(move) == Ticket.Taxi) score = score + 5;
                }
            }
            if (typeOfStop.isAllStops()){
                score = score + 10;
                if (max(maxPlayer.getTaxi(), maxPlayer.getBus(), maxPlayer.getUnderground()) == maxPlayer.getUnderground()) {
                    if (getMoveTicket(move) == Ticket.Underground) score = score + 5;
                    else if (max(maxPlayer.getTaxi(), maxPlayer.getBus()) == maxPlayer.getBus()) {
                        if (getMoveTicket(move) == Ticket.Bus) score = score + 5;
                    } else if (getMoveTicket(move) == Ticket.Taxi) score = score + 5;
                }
            }

            //check if detectives have suitable ticket to reach destination (in case not safe)
            if (!detectivesHaveTickets(view)) score = score + 1;

            // check if reveal round: prefer a destination with all transportation followed by secret move
            if (view.getCurrentRound() == 2 || view.getCurrentRound() == 7 || view.getCurrentRound() == 12
                    || view.getCurrentRound() == 17 || view.getCurrentRound() == 23) {
                if (isDoubleMove(view, move)) {
                    if (((DoubleMove) move).firstMove().ticket() != Ticket.Secret && ((DoubleMove) move).firstMove().ticket() == Ticket.Secret) {
                        if (typeOfStop.isAllStops()) score = score + 50;
                        else score = score + 30;
                    }
                    else {
                        if (((DoubleMove) move).firstMove().ticket() == Ticket.Secret && ((DoubleMove) move).firstMove().ticket() != Ticket.Secret) {
                            if (typeOfStop.isAllStops()) score = score + 30;
                            else score = score + 20;
                        }
                        else if (((DoubleMove) move).firstMove().ticket() == Ticket.Secret && ((DoubleMove) move).firstMove().ticket() == Ticket.Secret) {
                            score = score - 20;
                        }
                    }
                }
                else{
                    if (((TicketMove) move).ticket() == Ticket.Secret) score = score + 5;
                    if (typeOfStop.isAllStops()) score = score + 10;
                }
            }
            else{
                if (isDoubleMove(view,move)) score = score - 50;
                else{
                    if (((TicketMove) move).ticket() == Ticket.Secret) score = score - 50;
                }
            }

            return score;
        }

        private int scoreDetective(ScotlandYardView view, Move move, Colour colour){
            int score=0;

            // check if detective has ticket for destination next move
            if (playerHasNextTicket(view,move,colour))
                score = score - 10;
            else score = +100;

            nTypeOfStop(view,move);
            if (typeOfStop.isOnlyTaxi()) score = score - 1;
            if (typeOfStop.isTaxiAndBus()) score = score - 2;
            if (typeOfStop.isAllStops()) score = score - 3;

            //check if next destination is underground
            if (nextUnderground (view,move)) score = score + 1;

            //check if next round is reveal: prefer destination with all transports
            if (view.getCurrentRound() == 2 || view.getCurrentRound() == 7 || view.getCurrentRound() == 12
                    || view.getCurrentRound() == 17 || view.getCurrentRound() == 23) {
                if (nextUnderground (view,move)) score = score + 3;
            }
            // check if reveal: calculate distance from mrx
            /*if (view.getCurrentRound() == 3 || view.getCurrentRound() == 8 || view.getCurrentRound() == 13
                  || view.getCurrentRound() == 18 || view.getCurrentRound() == 24) {
            if (view.getCurrentRound()>= 3) {
                System.out.println(" " + view.getPlayerLocation(Colour.Black));
                if ((new Dijkstra(view,Colour.Black).getDistance(maxPlayer.getCurrentPosition()) == minDistance)  score = score + 10;
            }*/

             return score;
        }
    }
 }

