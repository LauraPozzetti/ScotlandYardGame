package uk.ac.bris.cs.scotlandyard.ui.ai;

import uk.ac.bris.cs.scotlandyard.model.*;
import uk.ac.bris.cs.scotlandyard.model.Move;
import uk.ac.bris.cs.scotlandyard.model.Player;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardView;
import uk.ac.bris.cs.scotlandyard.model.Transport;
import uk.ac.bris.cs.scotlandyard.model.*;


public class MiniMaxPlayer implements MoveVisitor {
    int bus;
    int taxi;
    int underground;
    int doubleT;
    int secret;
    final int position[];
    Colour colour;
    int round;
    boolean isMrX;
    int currentPosition;

    public MiniMaxPlayer(ScotlandYardView view, Colour col, int pos, boolean isMrx){
        position = new int[48];
        position[0] = pos;
        currentPosition = pos;
        colour = col;
        taxi = view.getPlayerTickets(colour, Ticket.Taxi);
        bus = view.getPlayerTickets(colour, Ticket.Bus);
        underground = view.getPlayerTickets(colour, Ticket.Underground);
        doubleT = view.getPlayerTickets(colour, Ticket.Double);
        secret = view.getPlayerTickets(colour, Ticket.Secret);
        round = view.getCurrentRound();
        isMrX = isMrx;
    }

    public void removeTicket(Move m) {
        //System.out.println("remove Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
        m.visit(new MoveVisitor() {
            @Override
            public void visit(PassMove move) {

            }

            @Override
            public void visit(TicketMove move) {
                if (move.ticket() == Ticket.Taxi) setTaxi(getTaxi() - 1);
                if (move.ticket() == Ticket.Bus) setBus(getBus() - 1);
                if (move.ticket() == Ticket.Underground) setUnderground(getUnderground() - 1);
                if (move.ticket() == Ticket.Secret) setSecret(getSecret() - 1);
                if (colour == Colour.Black) round++;
            }

            @Override
            public void visit(DoubleMove move) {
                setDouble(getDouble() - 1);
                if (move.firstMove().ticket() == Ticket.Taxi) setTaxi(getTaxi() - 1);
                if (move.firstMove().ticket() == Ticket.Bus) setBus(getBus() - 1);
                if (move.firstMove().ticket() == Ticket.Underground)
                    setUnderground(getUnderground() - 1);
                if (move.firstMove().ticket() == Ticket.Secret) setSecret(getSecret() - 1);
                if (move.secondMove().ticket() == Ticket.Taxi) setTaxi(getTaxi() - 1);
                if (move.secondMove().ticket() == Ticket.Bus) setBus(getBus() - 1);
                if (move.secondMove().ticket() == Ticket.Underground)
                    setUnderground(getUnderground() - 1);
                if (move.secondMove().ticket() == Ticket.Secret) setSecret(getSecret() - 1);
                if (colour == Colour.Black) round = round+2;

            }
        });
        //System.out.println("remove Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
    }

    public Colour colour(){ return colour;}

    public void addTicket(Move m) {
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
        m.visit(new MoveVisitor() {
            @Override
            public void visit(PassMove move) {

            }

            @Override
            public void visit(TicketMove move) {
                if (colour == Colour.Black) round--;
                if (move.ticket() == Ticket.Taxi) setTaxi(getTaxi() + 1);
                if (move.ticket() == Ticket.Bus) setBus(getBus() + 1);
                if (move.ticket() == Ticket.Underground) setUnderground(getUnderground() + 1);
                if (move.ticket() == Ticket.Secret) setSecret(getSecret() + 1);
            }

            @Override
            public void visit(DoubleMove move) {
                if (colour == Colour.Black) round = round - 2;
                setDouble(getDouble() + 1);
                if (move.firstMove().ticket() == Ticket.Taxi) setTaxi(getTaxi() + 1);
                if (move.firstMove().ticket() == Ticket.Bus) setBus(getBus() + 1);
                if (move.firstMove().ticket() == Ticket.Underground)
                    setUnderground(getUnderground() + 1);
                if (move.firstMove().ticket() == Ticket.Secret) setSecret(getSecret() + 1);
                if (move.secondMove().ticket() == Ticket.Taxi) setTaxi(getTaxi() + 1);
                if (move.secondMove().ticket() == Ticket.Bus) setBus(getBus() + 1);
                if (move.secondMove().ticket() == Ticket.Underground) setUnderground(getUnderground() + 1);
                if (move.secondMove().ticket() == Ticket.Secret) setSecret(getSecret() + 1);

            }
        });
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
    }

    public void addDetectiveTicketToMrX(Move m) {
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
        m.visit(new MoveVisitor() {
            @Override
            public void visit(PassMove move) {

            }

            @Override
            public void visit(TicketMove move) {
                if (move.ticket() == Ticket.Taxi) setTaxi(getTaxi() + 1);
                if (move.ticket() == Ticket.Bus) setBus(getBus() + 1);
                if (move.ticket() == Ticket.Underground) setUnderground(getUnderground() + 1);
            }

            @Override
            public void visit(DoubleMove move) {
             }
        });
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
    }

    public void removeDetectiveTicketFromMrX(Move m) {
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
        m.visit(new MoveVisitor() {
            @Override
            public void visit(PassMove move) {

            }

            @Override
            public void visit(TicketMove move) {
                if (move.ticket() == Ticket.Taxi) setTaxi(getTaxi() - 1);
                if (move.ticket() == Ticket.Bus) setBus(getBus() - 1);
                if (move.ticket() == Ticket.Underground) setUnderground(getUnderground() - 1);
            }

            @Override
            public void visit(DoubleMove move) {
            }
        });
        //System.out.println("add Taxi " + taxi + " bus " + bus + " underground " + underground + " secret " + secret + " double " + doubleT);
    }


    public void setPosition(int pos, int level) {
        position[level] = pos;}

    public void setPosition(Move m, int level) {
        m.visit(new MoveVisitor() {
            @Override
            public void visit(PassMove move) {

            }

            @Override
            public void visit(TicketMove move) {
                position[level] = move.destination();
                currentPosition = move.destination();
            }

            @Override
            public void visit(DoubleMove move) {
                position[level] = move.secondMove().destination();
                currentPosition = move.secondMove().destination();
            }
        });
    }

    public int getRound(){ return round;}

    public int getPosition(int level){ return position[level];}

    public int getCurrentPosition(){ return currentPosition;}

    public int getPlayerTickets(Ticket ticket){
        if (ticket == Ticket.Taxi) return taxi;
        if (ticket == Ticket.Bus) return bus;
        if (ticket == Ticket.Underground) return underground;
        if (ticket == Ticket.Double) return doubleT;
        if (ticket == Ticket.Secret) return secret;
        return -1;
    }

    public void setPlayerTickets(Ticket ticket, int value){
        if (ticket == Ticket.Taxi) taxi = value;
        if (ticket == Ticket.Bus) bus = value;
        if (ticket == Ticket.Underground) underground = value;
        if (ticket == Ticket.Double) doubleT = value;
        if (ticket == Ticket.Secret) secret = value;
    }

    public boolean isMrX(){ return isMrX;}

    public int getTaxi(){ return taxi;}

    public void setTaxi(int value){ taxi = value;}

    public int getBus(){ return bus;}

    public void setBus(int value){ bus = value;}

    public int getUnderground(){ return underground;}

    public void setUnderground(int value){ underground = value;}

    public int getDouble(){ return doubleT;}

    public void setDouble(int value){ doubleT = value;}

    public int getSecret(){ return secret;}

    public void setSecret(int value){ secret = value;}


}
