package uk.ac.bris.cs.scotlandyard.ui.ai;

import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.*;
import java.lang.Thread.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;


import uk.ac.bris.cs.scotlandyard.ai.ManagedAI;
import uk.ac.bris.cs.scotlandyard.ai.PlayerFactory;
import uk.ac.bris.cs.scotlandyard.model.Colour;
import uk.ac.bris.cs.scotlandyard.model.Move;
import uk.ac.bris.cs.scotlandyard.model.Player;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardView;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardPlayer;

// TODO name the AI
@ManagedAI("MyAI")
public class MyAI implements PlayerFactory {

	// TODO create a new player here
	@Override
	public Player createPlayer(Colour colour) {
		return new MyPlayer();
	}

	// TODO A sample player that selects a random move
	private static class MyPlayer implements Player {

		private final Random random = new Random();

		@Override
		public void makeMove(ScotlandYardView view, int location, Set<Move> moves,
				Consumer<Move> callback) {
			// TODO do something interesting here; find the best move
			// picks a random move
			if (new ArrayList<>(moves).size() == 1)
			{System.out.println("Allert");
			System.out.println(new ArrayList<>(moves).get(0));
			callback.accept(new ArrayList<>(moves).get(0));}
			else callback.accept(new ArrayList<>(moves).get(random.nextInt(moves.size())));

		}

		private Set<Move> moveFromOtherPlayer(int position, ScotlandYardPlayer other){
			Set<Move> dummyMove = new HashSet<>();
			return dummyMove;
		}
	}
}
