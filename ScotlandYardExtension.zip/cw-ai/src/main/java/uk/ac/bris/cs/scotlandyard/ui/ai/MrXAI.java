package uk.ac.bris.cs.scotlandyard.ui.ai;

import java.util.*;
import java.util.function.Consumer;

import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Graph;
import uk.ac.bris.cs.gamekit.graph.Node;
import uk.ac.bris.cs.scotlandyard.ai.ManagedAI;
import uk.ac.bris.cs.scotlandyard.ai.PlayerFactory;
import uk.ac.bris.cs.scotlandyard.model.*;

@ManagedAI("MrXAI")
public class MrXAI implements PlayerFactory {

    @Override
    public Player createPlayer(Colour colour) {
        return new MyPlayer();
    }

    private class MyPlayer implements Player {


        @Override
        public void makeMove(ScotlandYardView view, int location, Set<Move> moves,
                             Consumer<Move> callback) {

            // picks the best move
            callback.accept(getBestMove(view, moves));

        }
    }

    private List<Colour> getDetectives(ScotlandYardView view) {
        List<Colour> detectives = new ArrayList<>(view.getPlayers());
        detectives.remove(Colour.Black);
        return detectives;
    }

    private List<Node<Integer>> getDetectiveLocations(ScotlandYardView view, List<Colour> detectives) {
        List<Node<Integer>> locations = new ArrayList<>();
        Graph<Integer, Transport> graph = view.getGraph();
        for (Colour detective : detectives) {
            locations.add(graph.getNode(view.getPlayerLocation(detective)));
        }
        return locations;
    }


    //uses dijkstra's algorithm to calculate min distances from MrX to any node
    private HashMap<Node<Integer>, Integer> getMinDistancesToNodes(ScotlandYardView view, int mrXLoc) {
        Set<Node<Integer>> visitedNodes = new HashSet<>();
        Set<Node<Integer>> unvisitedNodes = new HashSet<>();
        List<Node<Integer>> adjacentNodes = new ArrayList<>();
        List<Node<Integer>> nodesToAdd = new ArrayList<>();
        List<Node<Integer>> nodesToRemove = new ArrayList<>();
        HashMap<Node<Integer>, Integer> distanceFromMrXMap = new HashMap<>();

        Graph<Integer, Transport> graph = view.getGraph();

        Node<Integer> mrXNode = graph.getNode(mrXLoc);
        unvisitedNodes.add(mrXNode);
        distanceFromMrXMap.put(mrXNode, 0);
        while (unvisitedNodes.size() > 0) {
            for (Node<Integer> n : unvisitedNodes) {
                visitedNodes.add(n);
                //get adjacent nodes of MrX
                Collection<Edge<Integer, Transport>> nodeEdges = graph.getEdgesFrom(n);
                for (Edge<Integer, Transport> e : nodeEdges) {
                    adjacentNodes.add(e.destination());
                }
                nodesToRemove.add(n);
                //for each of the adjacent Nodes, put the distance from Mrx into the distanceFromMrXMap map
                for (Node<Integer> nextNode : adjacentNodes) {
                    nodesToAdd.add(nextNode);
                    distanceFromMrXMap.putIfAbsent(nextNode, distanceFromMrXMap.get(n) + 1);
                }
            }
            unvisitedNodes.addAll(nodesToAdd);
            unvisitedNodes.removeAll(nodesToRemove);
        }
        return distanceFromMrXMap;
    }

    private Move getBestMove(ScotlandYardView view, Set<Move> moves) {
        List<Colour> detectives = getDetectives(view);
        List<Node<Integer>> detectiveLocs = getDetectiveLocations(view, detectives);
        TicketMove tm;
        DoubleMove dm;
        int MrXnewLoc, distanceToDetectiveScore = 0, numberOfDetectives1MoveAway = 0, numberOfDetectives2MovesAway = 0, numberOfDetective3MovesAway = 0;
        int distanceWeight = 5, numberOfDetective1MoveAwayWt = 10, numberOfDetectives2MovesAwayWt = 5, numberOfDetective3MoveAwayWt = 2;
        double nodeScore, maxNodeScore = 0;
        Integer distanceToDetective, detectiveDensityScore;
        Move bestScoreMove = null;

        for (Move m : moves) {
            if (m.getClass() == TicketMove.class) {
                tm = (TicketMove) m;
                MrXnewLoc = tm.destination();
            } else {
                dm = (DoubleMove) m;
                MrXnewLoc = dm.finalDestination();
            }
            HashMap<Node<Integer>, Integer> distanceFromMrXNewLocMap = getMinDistancesToNodes(view, MrXnewLoc);
            for (Node<Integer> detect : detectiveLocs) {
                distanceToDetective = distanceFromMrXNewLocMap.get(detect);
                distanceToDetectiveScore += distanceToDetective * distanceWeight;
                if (distanceToDetective == 1) {
                    numberOfDetectives1MoveAway += 1;
                } else if (distanceToDetective == 2) {
                    numberOfDetectives2MovesAway += 1;
                } else if (distanceToDetective == 3) {
                    numberOfDetective3MovesAway += 1;
                }
            }
            detectiveDensityScore = numberOfDetectives1MoveAway * numberOfDetective1MoveAwayWt
                    + numberOfDetectives2MovesAway * numberOfDetectives2MovesAwayWt
                    + numberOfDetective3MovesAway * numberOfDetective3MoveAwayWt;
            if (detectiveDensityScore != 0) {
                nodeScore = distanceToDetectiveScore / detectiveDensityScore;
            } else nodeScore = distanceToDetectiveScore;
            if (nodeScore > maxNodeScore) {
                maxNodeScore = nodeScore;
                bestScoreMove = m;
            }
        }
        return bestScoreMove;
    }
}
