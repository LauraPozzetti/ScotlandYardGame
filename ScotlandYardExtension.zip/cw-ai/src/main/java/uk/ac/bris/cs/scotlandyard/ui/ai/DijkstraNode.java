package uk.ac.bris.cs.scotlandyard.ui.ai;


public class DijkstraNode {
    private int node;
    private int distance;  // shortest known distance from "source"
    private DijkstraNode previous;  // previous node
    private boolean visited; // all false initially
    private int  bus;
    private int taxi;
    private int underground;

    public DijkstraNode (int node){
        this.node = node;
        this.distance = Integer.MAX_VALUE; // 0 se sorgente, infinito per tutti gli altri
        this.taxi = 0;
        this.bus = 0;
        this.underground= 0;
        this.visited = false;
    }

    public void setDistance (int value) {distance = value;}

    public int getDistance() {return distance;}

    public void setPrevious (DijkstraNode value) {previous = value;}

    public DijkstraNode getPrevious() {return previous;}

    public void setVisited (boolean value) {visited = value;}

    public boolean getVisited() {return visited;}

    public void setTaxi (int value) {taxi = value;}

    public int getTaxi() {return taxi;}

    public void setBus (int value) {bus = value;}

    public int getBus() {return bus;}

    public void setUnderground (int value) {underground = value;}

    public int getUnderground() {return underground;}
}
