package uk.ac.bris.cs.scotlandyard.ui.ai;
import uk.ac.bris.cs.scotlandyard.model.*;
import uk.ac.bris.cs.scotlandyard.model.Ticket;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.*;
import java.lang.Thread.*;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import java.util.function.Consumer;

import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;
import static uk.ac.bris.cs.scotlandyard.model.Colour.Black;
import static uk.ac.bris.cs.scotlandyard.model.Ticket.Taxi;

import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Graph;

public class DijkstraSave {
    private final int [] distance;  // shortest known distance from "source"
    private int [] previous;  // previous node
    private boolean [] visited; // all false initially
    private int [] bus;
    private int[] taxi;
    private int [] underground;
    List<DijkstraNode> nodeList;

    public DijkstraSave(ScotlandYardView view, Colour colour, int source) {
        Graph<Integer, Transport> graph = view.getGraph();
        this.distance = new int[graph.getNodes().size() + 1];  // shortest known distance from "source"
        this.previous = new int[graph.getEdges().size() + 1];  // previous node
        this.bus = new int[graph.getEdges().size() + 1];  // previous node
        this.taxi = new int[graph.getEdges().size() + 1];  // previous node
        this.underground = new int[graph.getEdges().size() + 1];  // previous node
        this.visited = new boolean[graph.getEdges().size() + 1]; // all false initially

        nodeList = new ArrayList<>();
        //System.out.println("Giocatore " + colour + " posizione " + source);
        if(source > 0 && source < (graph.getNodes().size() + 1)){
            //initialization
            for (int i = 0; i < distance.length; i++) {
                nodeList.add(new DijkstraNode(i));
                distance[i] = Integer.MAX_VALUE;
                taxi[i] = 0;
                bus[i] = 0;
                underground[i] = 0;
                visited[i] = false;
            }
            distance[source] = 0;
            //  System.out.println(nodeList.get(source).getDistance());
            nodeList.get(source).setDistance(0);
            //    System.out.println(nodeList.get(source).getDistance());

            int current = minDistance();
            System.out.println("Current " + current);
            while(current != -1){
                visited[current] = true;
                Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(current));
                for (Edge<Integer, Transport> e : edges) {
                    if (distance[e.destination().value()] > distance[current] + 1) {
                        if (checkTicket(view, current, colour, Ticket.fromTransport(e.data()) )) {
                            distance[e.destination().value()] = distance[current] + 1;
                            previous[e.destination().value()] = current;
                            refreshTicket(view, current, colour, Ticket.fromTransport(e.data()), e.destination().value());
                        }
                    }
                }
                current = minDistance();
            }

            int current2 = minDistance2();
            System.out.println("Current2 " + current2);
            while(current2 != -1){
                nodeList.get(current2).setVisited(true);
                Collection<Edge<Integer, Transport>> edges = graph.getEdgesFrom(graph.getNode(current2));
                for (Edge<Integer, Transport> e : edges) {
                    if (nodeList.get(e.destination().value()).getDistance() > nodeList.get(current2).getDistance() + 1) {
                        if (checkTicket2(view, current2, colour, Ticket.fromTransport(e.data()) )) {
                            nodeList.get(e.destination().value()).setDistance(nodeList.get(current2).getDistance() + 1);
                            nodeList.get(e.destination().value()).setPrevious(nodeList.get(current2));
                            refreshTicket2(view, current2, colour, Ticket.fromTransport(e.data()), e.destination().value());
                        }
                    }
                }
                current2 = minDistance2();
            }
        }
        for (int i = 1; i < distance.length; i++) {
            System.out.println("Nodo " + i + " " + " distance " + distance[i] + " visitato " + visited[i] +  " taxi " + taxi[i] + " bus " + bus[i] + " underground " + underground[i]);
            System.out.println("Nodo " + i + " " + " distance " + nodeList.get(i).getDistance() + " visitato " + nodeList.get(i).getVisited() +  " taxi " + nodeList.get(i).getTaxi() + " bus " + nodeList.get(i).getBus() + " underground " + nodeList.get(i).getUnderground());
        }
    }


    private boolean checkTicket(ScotlandYardView view, int current, Colour colour, Ticket ticket){
        boolean check = true;
        if (colour == Colour.Black) return check;
        if (ticket == Ticket.Taxi) {
            if (view.getPlayerTickets(colour, Ticket.Taxi) < taxi[current] + 1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < bus[current]) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < underground[current]) check = false;
        }
        if (ticket == Ticket.Bus){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < taxi[current]) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < bus[current] + 1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < underground[current]) check = false;
        }
        if (ticket == Ticket.Underground){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < taxi[current]) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < bus[current]) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < underground[current]+1) check = false;
        }
        return check;
    }

    private boolean checkTicket2(ScotlandYardView view, int current, Colour colour, Ticket ticket){
        boolean check = true;
        if (colour == Colour.Black) return check;
        if (ticket == Ticket.Taxi) {
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi() + 1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Bus){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()+1) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()) check = false;
        }
        if (ticket == Ticket.Underground){
            if (view.getPlayerTickets(colour, Ticket.Taxi) < nodeList.get(current).getTaxi()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Bus) < nodeList.get(current).getBus()) check = false;
            if (view.getPlayerTickets(colour, Ticket.Underground) < nodeList.get(current).getUnderground()+1) check = false;
        }
        return check;
    }

    private void refreshTicket(ScotlandYardView view, int current, Colour colour, Ticket ticket, int destination){
        if (ticket == Ticket.Taxi) {
            taxi[destination] = taxi[current]+1;
            bus[destination] = bus[current];
            underground[destination] = underground[current];
        }
        if (ticket == Ticket.Bus) {
            taxi[destination] = taxi[current];
            bus[destination] = bus[current] + 1;
            underground[destination] = underground[current];
        }
        if (ticket == Ticket.Underground) {
            taxi[destination] = taxi[current];
            bus[destination] = bus[current];
            underground[destination] = underground[current] + 1;
        }
    }

    private void refreshTicket2(ScotlandYardView view, int current, Colour colour, Ticket ticket, int destination){
        if (ticket == Ticket.Taxi) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi() + 1);
            nodeList.get(destination).setBus( nodeList.get(current).getBus());
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground());
        }
        if (ticket == Ticket.Bus) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi());
            nodeList.get(destination).setBus( nodeList.get(current).getBus()+1);
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground());
        }
        if (ticket == Ticket.Underground) {
            nodeList.get(destination).setTaxi( nodeList.get(current).getTaxi());
            nodeList.get(destination).setBus( nodeList.get(current).getBus());
            nodeList.get(destination).setUnderground( nodeList.get(current).getUnderground()+1);
        }
    }

    private int minDistance2 () {
        int x = Integer.MAX_VALUE;
        int y = -1;   // graph not connected, or no unvisited vertices
        for (int i=0; i<nodeList.size(); i++) {
            if (!nodeList.get(i).getVisited() && nodeList.get(i).getDistance()<x) {
                y=i;
                x=nodeList.get(i).getDistance();}
        }
        return y;
    }

    private int minDistance () {
        int x = Integer.MAX_VALUE;
        int y = -1;   // graph not connected, or no unvisited vertices
        for (int i=0; i<distance.length; i++) {
            if (!visited[i] && distance[i]<x) {
                y=i;
                x=distance[i];}
        }
        return y;
    }

    public int getDistance(int destination){
        return distance[destination];
    }

    public int getNumberTaxi(int destination){
        return taxi[destination];
    }

    public int getNumberBus(int destination){
        return bus[destination];
    }

    public int getNumberUnderground(int destination){
        return underground[destination];
    }
}


